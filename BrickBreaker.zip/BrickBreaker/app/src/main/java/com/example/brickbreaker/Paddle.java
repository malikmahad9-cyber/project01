package com.example.brickbreaker;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class Paddle {

    float x, y;
    float width, height;

    Paint paint;

    public Paddle(float x, float y) {

        this.x = x;
        this.y = y;

        width = 300;
        height = 40;

        paint = new Paint();
        paint.setColor(Color.WHITE);
    }

    public void draw(Canvas canvas) {

        canvas.drawRect(
                x,
                y,
                x + width,
                y + height,
                paint
        );
    }

    public RectF getRect() {

        return new RectF(
                x,
                y,
                x + width,
                y + height
        );
    }
}