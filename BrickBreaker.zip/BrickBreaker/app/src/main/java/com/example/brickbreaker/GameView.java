package com.example.brickbreaker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public class GameView extends View {

    Paint paint = new Paint();

    // Paddle
    float paddleX = 300;
    float paddleY = 1700;
    float paddleWidth = 300;
    float paddleHeight = 40;

    // Ball
    float ballX = 500;
    float ballY = 1000;
    float ballRadius = 25;

    float ballSpeedX = 15;
    float ballSpeedY = 15;

    // Bricks
    RectF[][] bricks;
    boolean[][] brickVisible;

    int rows = 4;
    int cols = 6;

    int score = 0;

    boolean gameOver = false;
    boolean gameWon = false;

    public GameView(Context context) {
        super(context);

        bricks = new RectF[rows][cols];
        brickVisible = new boolean[rows][cols];

        createBricks();
    }

    private void createBricks() {

        float brickWidth = 150;
        float brickHeight = 60;

        for (int r = 0; r < rows; r++) {

            for (int c = 0; c < cols; c++) {

                float left = c * (brickWidth + 20) + 30;

                float top = r * (brickHeight + 20) + 100;

                bricks[r][c] = new RectF(
                        left,
                        top,
                        left + brickWidth,
                        top + brickHeight
                );

                brickVisible[r][c] = true;
            }
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Background
        canvas.drawColor(Color.BLACK);

        // Paddle
        paint.setColor(Color.WHITE);

        canvas.drawRect(
                paddleX,
                paddleY,
                paddleX + paddleWidth,
                paddleY + paddleHeight,
                paint
        );

        // Ball
        paint.setColor(Color.YELLOW);

        canvas.drawCircle(
                ballX,
                ballY,
                ballRadius,
                paint
        );

        // Bricks
        paint.setColor(Color.RED);

        for (int r = 0; r < rows; r++) {

            for (int c = 0; c < cols; c++) {

                if (brickVisible[r][c]) {

                    canvas.drawRect(
                            bricks[r][c],
                            paint
                    );
                }
            }
        }

        // Score
        paint.setColor(Color.WHITE);
        paint.setTextSize(60);

        canvas.drawText(
                "Score: " + score,
                50,
                70,
                paint
        );

        // Game Over
        if (gameOver) {

            paint.setTextSize(100);

            canvas.drawText(
                    "GAME OVER",
                    180,
                    900,
                    paint
            );
        }

        // Win
        if (gameWon) {

            paint.setTextSize(100);

            canvas.drawText(
                    "YOU WIN!",
                    220,
                    900,
                    paint
            );
        }

        // Update game only if game running
        if (!gameOver && !gameWon) {

            update();

            invalidate();
        }
    }

    private void update() {

        // Move ball
        ballX += ballSpeedX;
        ballY += ballSpeedY;

        // Left and Right Wall Collision
        if (ballX <= ballRadius ||
                ballX >= getWidth() - ballRadius) {

            ballSpeedX = -ballSpeedX;
        }

        // Top Wall Collision
        if (ballY <= ballRadius) {

            ballSpeedY = -ballSpeedY;
        }

        // Bottom Collision = Game Over
        if (ballY >= getHeight()) {

            gameOver = true;

            ballSpeedX = 0;
            ballSpeedY = 0;
        }

        // Paddle Rectangle
        RectF paddle = new RectF(
                paddleX,
                paddleY,
                paddleX + paddleWidth,
                paddleY + paddleHeight
        );

        // Paddle Collision
        if (paddle.contains(
                ballX,
                ballY + ballRadius)) {

            ballY = paddleY - ballRadius;

            ballSpeedY = -Math.abs(ballSpeedY);
        }

        // Brick Collision
        for (int r = 0; r < rows; r++) {

            for (int c = 0; c < cols; c++) {

                if (brickVisible[r][c]) {

                    if (bricks[r][c].contains(
                            ballX,
                            ballY)) {

                        brickVisible[r][c] = false;

                        ballSpeedY = -ballSpeedY;

                        score++;
                    }
                }
            }
        }

        // Win Condition
        if (score == rows * cols) {

            gameWon = true;

            ballSpeedX = 0;
            ballSpeedY = 0;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        // Move paddle with finger
        paddleX = event.getX() - paddleWidth / 2;

        // Prevent leaving screen
        if (paddleX < 0) {

            paddleX = 0;
        }

        if (paddleX + paddleWidth > getWidth()) {

            paddleX = getWidth() - paddleWidth;
        }

        return true;
    }
}