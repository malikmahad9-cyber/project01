package com.example.brickbreaker;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Ball {

    float x, y;
    float radius;
    float speedX, speedY;

    Paint paint;

    public Ball(float x, float y, float radius) {

        this.x = x;
        this.y = y;
        this.radius = radius;

        speedX = 10;
        speedY = 10;

        paint = new Paint();
        paint.setColor(Color.YELLOW);
    }

    public void draw(Canvas canvas) {
        canvas.drawCircle(x, y, radius, paint);
    }

    public void move() {
        x += speedX;
        y += speedY;
    }
}