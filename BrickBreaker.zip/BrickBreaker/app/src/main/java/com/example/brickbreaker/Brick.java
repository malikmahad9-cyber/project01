package com.example.brickbreaker;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class Brick {

    RectF rect;
    boolean visible = true;

    Paint paint;

    public Brick(float left, float top, float right, float bottom) {

        rect = new RectF(left, top, right, bottom);

        paint = new Paint();
        paint.setColor(Color.RED);
    }

    public void draw(Canvas canvas) {

        if (visible) {
            canvas.drawRect(rect, paint);
        }
    }
}